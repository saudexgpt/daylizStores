Tinymce/components/EditorImage.vue
